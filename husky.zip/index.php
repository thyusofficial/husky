<?php
header('Location: app/views/home.php');
