<?php
class ErrorController
{
  public  function index()
  {
    echo 'Error page';
  }
}
